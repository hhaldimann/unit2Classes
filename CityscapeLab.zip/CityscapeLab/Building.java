import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Color;

/**
 * This class will create 3 buildings.
 * 
 * @author hhaldimann
 * @version 3 October 2014
 */
public class Building
{
    /** Placement of building from x axis to the left */
    private int xLeft;
    /** Placement of building from y axis down*/
    private int yTop;
   
    /**
     * Default constructor for objects of class Building
     */
    public Building(int x, int y)
    {
        xLeft = x;
        yTop = y;
    }

    /**
     * An example of a method - replace this comment with your own
     *    that describes the operation of the method
     *
     * @pre        preconditions for the method
     *            (what the method assumes about the method's parameters and class's state)
     * @post    postconditions for the method
     *            (what the method guarantees upon completion)
     * @param    y    description of parameter y
     * @return    description of the return value
     */
    public void draw(Graphics2D g2)
    {
        Rectangle building = new Rectangle(xLeft + 50, yTop + 50, 100, 325);
        g2.draw(building);
        g2.setColor(Color.GRAY);
        g2.fill(building);
        Rectangle window1 = new Rectangle(xLeft + 62, yTop + 300, 25, 25);
        Rectangle window2 = new Rectangle(xLeft + 110, yTop + 300, 25, 25);
        Rectangle window3 = new Rectangle(xLeft + 62, yTop + 225, 25, 25);
        Rectangle window4 = new Rectangle(xLeft + 110, yTop + 225, 25, 25);
        Rectangle window5 = new Rectangle(xLeft + 62, yTop + 150, 25, 25); 
        Rectangle window6 = new Rectangle(xLeft + 110, yTop + 150, 25, 25);
        Rectangle window7 = new Rectangle(xLeft + 62, yTop + 75, 25, 25);
        Rectangle window8 = new Rectangle(xLeft + 110, yTop + 75, 25, 25);        
        g2.draw(window1);
        g2.setColor(Color.WHITE);
        g2.fill(window1);
        g2.draw(window2);
        g2.fill(window2);
        g2.draw(window3);
        g2.fill(window3);
        g2.draw(window4);
        g2.fill(window4);
        g2.draw(window5);
        g2.fill(window5);
        g2.draw(window6);
        g2.fill(window6);
        g2.draw(window7);
        g2.fill(window7);
        g2.draw(window8);
        g2.fill(window8);
        
    }

}
